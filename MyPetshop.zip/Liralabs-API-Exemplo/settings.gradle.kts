rootProject.name = "com.liralabs.paris"
